from rest_framework import viewsets, filters
from clientes.serializers import ClienteSerializer
from clientes.models import Cliente

from django_filters.rest_framework import DjangoFilterBackend

class ClientesViewSet(viewsets.ModelViewSet):
    """Listando clientes"""
    queryset = Cliente.objects.all()
    serializer_class = ClienteSerializer
    # Cria ordenação e filtro  na página do rest
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter, filters.SearchFilter]
    # Para poder ordenar por qualquer campo, basta comentar a linha abaixo (ordering_fields)
    ordering_fields = ['nome']
    search_fields = ['nome', 'cpf'] # busca por nome ou cpf que CONTÉM a informação passada
    filterset_fields = ['ativo']

