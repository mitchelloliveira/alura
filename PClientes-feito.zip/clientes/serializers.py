
from rest_framework import serializers
from clientes.models import Cliente
from clientes.validators import *

class ClienteSerializer(serializers.ModelSerializer):
    class Meta:
        model = Cliente
        fields = '__all__'
    
    # função de validação de dados. O parametro data receberá os campos para validar
    def validate(self, data):

        if not nome_valido(data['nome']):
            raise serializers.ValidationError({"nome":"Não inclua números nesse campo."})

        if not cpf_valido(data['cpf']):
            raise serializers.ValidationError({"cpf":"Número de CPF inválido."})

        if not rg_valido(data['rg']):
            raise serializers.ValidationError({"rg":"O RG deve ter até 9 digitos."})

        if not celular_valido(data['celular']):
            raise serializers.ValidationError({"celular":"O DDD+Celular deve ter 11 digitos (99)99999-9999."})

        return data




